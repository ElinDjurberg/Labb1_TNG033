#include "set.hpp"

// skapar ny nod i ett set
void Set::insert(Node* p, int value) const {

	auto newNode = new Node(value, nullptr);

	// uppdaterar pekarna
	//insertar efter p
	newNode->next = p->next;
	p->next = newNode;
}

void Set::remove(Node* p) {
	//deletar noden som p pekar p�.
	delete p;
	p = nullptr;

}


// Default constructor
Set::Set()
{
	//I set.hpp class Node finns en constructor som beh�ver en int samt en pointer f�r initalizering

	head = new Node(0, nullptr); 
	//Detta �r en nod med en tom efterf�ljare
	// kan inte deleta h�r f�r d� finns inget att skicka vidare 
}

// Constructor for creating a set from an int
Set::Set(int v) : Set()
{	
	head->next = new Node(v, nullptr);
}

// Constructor creating a set
// a non-sorted array of n intgers
Set::Set(const int a[], int n) :Set()
{
	//Vi m�ste peka p� array f�r den �r constant s� vi kan ej �ndra den
	int *newArray = new int[n];

	//Anv�nder pekaren f�r att l�gga in v�rden fr�n a i den nya arrayn vi har skapat. Nu kan vi komma �t dem
	for (int i = 0; i < n; i++) {
		newArray[i] = a[i];
	}

	//sortering
	int temp = 0;
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (newArray[i] > newArray[j]) {

				temp = newArray[j];
				newArray[j] = newArray[i];
				newArray[i] = temp;

			}
		}
	}


	Node* dummy = head;

	// tar v�rdena fr�n den nya arrayen och s�tter som values i ett nytt sett av noder ( singled linked list)
	for (int i = 0; i < n; i++) {
		int value = newArray[i];

		insert(dummy, value);

		// uppdatera dummy, annars hamnar noderna som bakv�nt, man l�gger in �t fel h�ll
		dummy = dummy->next;
	}
	// om vi deletar newArray med hake [] tar vi bort hela arrayen som pekren newArray pekar p�
	delete[] newArray;
	newArray = nullptr;

	/*
	K�ra delete manuellt f�r remove funktionen tar bara bort noder
	*/
}



//Kopiera fr�n S och l�gga in i R
// copy constructor
Set::Set(const Set& source) : Set()
{
	Node* temp = source.head; // head till S
	temp = temp->next; // pekar p� f�rsta riktiga noden, hoppar �ver dummyNode

	Node* tail = head; // denna ska f�lja med l�ngs hela R, head till R

	while (temp != nullptr) {

		/*Node* newNode = new Node(temp->value, nullptr);*/
		/*tail->next = newNode; // knyter ihop R*/

		insert(tail, temp->value);

		tail = tail->next; // samma som tail=newNode;
		temp = temp->next; // pekar p� n�sta nod i S, som ska kopieras
	}
}

// Destructor: deallocate all nodes
Set::~Set()
{
	//g� node f�r node och delete p;
	// �r redan inne i set, s� vi n�r head
	Node* current = head;
	
	//delete head;
	while (current != nullptr) {

		//b�rjar framifr�n och g�r igenom hela listan
		//finns dummy next s� hoppa fram ett steg tills man kommit till slutet. 

		Node* soon = current->next;

		// delete current;
		remove(current);

		// s�tter om current fr�n nullptr i remove funktionen till soon
		current = soon;
	}
}


/*
S�tter man const efter en funktion skaobjektet INTE �ndras
In: A
Ut: A

dvs INGA borttagna/tillagda noder, �ndrande av pointer eller value i noderna

t.ex en person in (namn, �lder)
kontrollera nmanet och �lder, INTE �ndra n�got, endast kontrollera
*/


// Test if set is empty
bool Set::empty() const
{
	return head->next == nullptr;
	// returnerar true eller false om
	// true om head -> next==nullptr;
	//false om head -> next!=nullptr;
}

// Return number of elements in the set
// number of nodes in the set
int Set::cardinality() const
{
	//whileloop och r�kna antal
	int counter = 0;
	//ta head->next f�r att inte r�kna med dummyNode
	Node* dummy = head->next;


	while (dummy != nullptr) {
		counter++;
		dummy = dummy->next;
	}

	return counter;
}

// Test if x is an element of the set
bool Set::member(int x) const
{
	Node* search = head->next;

	while (search != nullptr) {
		//om man hittar v�rdet man s�ker efter return true och avsluta
		if (search->value == x) {
			return true;
		}
		search = search->next;
	}

	return false; 
}

// Assignment operator
Set& Set::operator=(Set s)
{  //s.head no copy
	//copy and swap idiom
	//Set copy(s);
	std::swap(head, s.head);
	// hela objektet returneras
	//delocate automatiskt
	return *this; 
	
}

//Kollar om det �r ett subset/delmm�ngd
bool Set::operator<=(const Set& b) const
{
	bool isSubset = false;
	Node* dummy = head->next;//hoppar �ver till f�rsta tal
	Node* dummyB = b.head->next;
	int counter = 0;

	//Kollar om vi �r i en tom f�r d� kommer det alltid vara sant
	if (this->empty()) {
		isSubset = true;
		return isSubset;
	}

	while (dummy != nullptr) {

		while (dummyB != nullptr) {

			if (dummyB->value == dummy->value) {
				counter++;
			}
			dummyB = dummyB->next;

		}
		//resetta dummy 
		dummyB = b.head->next;
		dummy = dummy->next;

	}
	//om den har hittat lika m�nga element som finns i listan som den �r l�ng s� �r det en delm�ngd
	//alla talen i det lilla settet ska finnas i det st�rre. Countern �kar varje g�ng det lilla settet->value �r samma som stora settets value
	if (counter == this->cardinality()) {
		isSubset = true;
	}

	return isSubset;
}

bool Set::operator==(const Set& b) const
{
	
	return !(*this != b);
}

bool Set::operator!=(const Set& b) const
{
	
	bool isSubset = true;

	if ((*this <= b) && (b.cardinality() == this->cardinality())) {
		isSubset = false;
	}
	
	return isSubset;

}

bool Set::operator<(const Set& b) const
{

	bool isSubset = false;

	if ((this <= &b) && (b.cardinality() > this->cardinality())) {
		isSubset = true;
	}

	return isSubset;  
}

// Set union
// Repeated values are not allowed
Set Set::operator+(const Set& b) const
{
	// Add code
	Set newSet = Set();//Dummy node till v�rt nya set

	Node* pointerB = b.head->next;
	Node* pointerR = head->next;	//N�r vi setet vi �r i sett R//Ja vi n�r R
	//vi skriver head next f�r att inte r�kna med v�r dummynode!

	Node* dummyNew = newSet.head;


	while ((pointerB != nullptr) && (pointerR != nullptr)) {

		if (pointerB->value < pointerR->value) {
			//skapa en ny lista

			insert(dummyNew, pointerB->value);
			//dummyNew->next = new Node(pointerB->value, nullptr);
			pointerB = pointerB->next;
			dummyNew = dummyNew->next;
		}

		else if (pointerR->value < pointerB->value) {
			//l�gga till p� lista
			insert(dummyNew, pointerR->value);
			//dummyNew->next = new Node(pointerR->value, nullptr);
			pointerR = pointerR->next;
			dummyNew = dummyNew->next;
		}

		else {
			//om de �r samma 
			//l�gg till i list

		/*Node* newNode = new Node(temp->value, nullptr);*/
		/*tail->next = newNode; // knyter ihop R*/
			insert(dummyNew, pointerR->value);

			//dummyNew->next = new Node(dummyR->value, nullptr);
			pointerR = pointerR->next;
			pointerB = pointerB->next;
			dummyNew = dummyNew->next;
		}


	}

	//L�gg till i listorna
	while (pointerB != nullptr) {
		//L�gg till resterande i listan


		//dummyNew->next = insert
		insert(dummyNew, pointerB->value);
		//dummyNew->next = new Node(dummyB->value, nullptr);
		pointerB = pointerB->next;
		dummyNew = dummyNew->next;

	}

	while (pointerR != nullptr) {
		//L�gg till resten i listan



		insert(dummyNew, pointerR->value);
		//dummyNew->next = new Node(pointerR->value, nullptr);
		pointerR = pointerR->next;
		dummyNew = dummyNew->next;

	}

	return newSet;  // to be deleted
}

// Set intersection
Set Set::operator*(const Set& b) const
{
	
	Set newSet = Set();//Dummy node till v�r nya s�tt

	Node* dummyB = b.head->next;
	Node* dummyR = head->next;	//N�r vi setet vi �r i sett R//Ja vi n�r R
	//vi skriver head next f�r att inte r�kna med v�r dummynode!

	Node* dummyNew = newSet.head;


	while (dummyB != nullptr) {

		while (dummyR != nullptr) {

			if (dummyB->value == dummyR->value) {
				//skapa en ny lista

				insert(dummyNew, dummyB->value);
				//dummyNew->next = new Node(dummyB->value, nullptr);
				//de* List = new Node()

				dummyNew = dummyNew->next;
			}

			dummyR = dummyR->next;

		}
		//Detta �r f�r att resetta dummyR annars �r den l�ngst bort i arrayn! Detta gl�mde vi
		dummyR = head->next;

		dummyB = dummyB->next;
	}

	return newSet;  // to be deleted
}

// Set difference
Set Set::operator-(const Set& b) const
{
	Set newSet = Set();

	Node* dummyB = b.head->next;
	Node* dummyR = head->next;
	Node* dummyNew = newSet.head;

	while (dummyR != nullptr) {

		int counter = 0;

		while (dummyB != nullptr) {

			if (dummyR->value == dummyB->value) {

				counter++;
			}

			dummyB = dummyB->next;

		}

		dummyB = b.head->next;//vi m�ste resetta dummy B till n�sta loop

		if (counter == 0) {
			insert(dummyNew, dummyR->value);
			//dummyNew->next = new Node(dummyR->value, nullptr);
			dummyNew = dummyNew->next;
		}

		dummyR = dummyR->next;
	}
	//ska n�got tas bort h�r??
	return newSet;  // to be deleted
}

// Set union with set {x}
Set Set::operator+(int x) const
{

	//g�r ett nytt s�tt med det v�rdet vi fick in
	Set *newInt = new Set(x);
	//anv�nder v�r operator+ som vi skapat.
	const Set combinedSet = *this + *newInt;

	delete newInt;//vi beh�ver deleta annars memory leaks
	return combinedSet;

}

// Set difference with set {x}
Set Set::operator-(int x) const
{
	// Add code

	//g�r ett nytt s�tt med det v�rdet vi fick in
	Set *newInt = new Set(x);
	//anv�nder v�r operator- som vi skapat.
	const Set combinedSet = *this - *newInt;
	delete newInt;
	return combinedSet;
}



std::ostream& operator<<(std::ostream& os, const Set& theSet)
{
	if (theSet.empty())
	{
		os << "Set is empty!";
	}
	else
	{
		Set::Node* temp = theSet.head->next;
		os << "{ ";

		while (temp)
		{
			os << temp->value << " ";
			temp = temp->next;
		}
		os << "}";
	}

	return os;
}